import Algorithms
import pandas as pd

df = pd.read_csv('University2.csv')
name=df.Name.values.tolist()
acronym=df.Acronym.values.tolist()
address=df.Address.values.tolist()
founded=df.Founded.values.tolist()
motto=df.Motto.values.tolist()
worldRank=df.WorldRank.values.tolist()
countryRank=df.CountryRank.values.tolist()
phone=df.Phone.values.tolist()
fax=df.Fax.values.tolist()
class University():
    Name=""
    Acronym=""
    Address=""
    Founded=0
    Motto=""
    WorldRank=0
    CountryRank=0
    Phone=""
    Fax=""
    def __init__(self,name,acronym,address,founded,motto,worldRank,countryRank,phone,fax):
        self.Name=name
        self.Acronym=acronym
        self.Address=address
        self.Founded=founded
        self.Motto=motto
        self.WorldRank=worldRank
        self.CountryRank=countryRank
        self.Phone=phone
        self.Fax=fax
totalUniversities=[]
for i in range(0,len(name)):
    ob=University(name[i],acronym[i],address[i],founded[i],motto[i],worldRank[i],countryRank[i],phone[i],fax[i])
    totalUniversities.append(ob)
def sortingAlgorithms(startInd,endInd, array,attribute):
    def Merge(start,m,end,array):
        n1=m-start+1
        n2=end-m
        l=[None]*(n1)
        r=[None]*(n2)
        for i in range(0,n1):
            l[i]=array[start+i]
        for i in range(0,n2):
            r[i]=array[m+1+i]
        i=0
        j=0
        k=start
        while i<n1 and j<n2:
            if(getattr(l[i],attribute)>getattr(r[j],attribute)):
                array[k]=r[j]
                j+=1
                k+=1
            else:
                array[k]=l[i]
                i+=1
                k+=1
        while i<n1:
            array[k]=l[i]
            i+=1
            k+=1
        while j<n2:
            array[k]=r[j]
            j+=1
            k+=1
    def MergeSort1(startInd,endInd,array):
        if(startInd<endInd):
            m=((endInd-1)+startInd)//2
            MergeSort1(startInd, m, array)
            MergeSort1(m+1, endInd, array)
            Merge(startInd,m,endInd,array)
        return array
    return MergeSort1(startInd,endInd,array)




def MultiSorting(attribute,indexArray):
    global totalUniversities
    for i in range(0,len(indexArray)-1):
        totalUniversities=sortingAlgorithms(indexArray[i],indexArray[i+1]-1,totalUniversities,attribute)
    temp=getattr(totalUniversities[0],attribute)
    indexArray=[]
    indexArray.append(0)
    if(attribute == "Founded" or attribute == "WorldRank" or attribute == "CountryRank" ):
        previousAsc=temp
        ascValue=0
        for i in range(0,len(totalUniversities)):
            ascValue=getattr(totalUniversities[i],attribute)
            if(ascValue!=previousAsc):
                indexArray.append(i)
                previousAsc=ascValue
    else:
        previousAsc=ord(temp[0])
        ascValue=0
        for i in range(0,len(totalUniversities)):
            temp=totalUniversities[i].Name
            ascValue=ord(temp[0])
            if(ascValue!=previousAsc):
                indexArray.append(i)
                previousAsc=ascValue




#    for i in range(0,len(indexArray)-1):
 #       totalUniversities=sortingAlgorithms(indexArray[i],indexArray[i+1]-1,totalUniversities,"Founded")
    # for i in range(0,len(totalUniversities)):
    #     print(totalUniversities[i].Acronym)
    #     print(i)











    #Save Data in file
    name=[]
    acronym=[]
    address=[]
    founded=[]
    motto=[]
    worldRank=[]
    countryRank=[]
    phone=[]
    fax=[]
    for i in totalUniversities:
        name.append(i.Name)
        acronym.append(i.Acronym)
        address.append(i.Address)
        founded.append(i.Founded)
        motto.append(i.Motto)
        worldRank.append(i.WorldRank)
        countryRank.append(i.CountryRank)
        phone.append(i.Phone)
        fax.append(i.Fax)
    df = pd.DataFrame({'Name':name, 'Acronym':acronym, 'Address':address,'Founded':founded,'Motto':motto,'WorldRank':worldRank,'CountryRank':countryRank,'Phone':phone,'Fax':fax})
    df.to_csv('University2.csv', index=False, encoding='utf-8')
    return indexArray
#MultiSorting(totalUniversities,"Name")
    