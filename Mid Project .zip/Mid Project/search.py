#import Algorithms
import pandas as pd




def linearSearch(attribute , key  ):
    key=key.replace(",","")
    key=key.replace(" ","")
    class UniversityData:
        Name=""
        Acronym=""
        Address=""
        Founded=0
        Motto=""
        WorldRank=0
        CountryRank=0
        Phone=""
        Fax=""

        def __init__(self,name , acronyms , address,founded , motto , world_rank , country_rank,telephone_number , fax):
            self.Name = name
            self.Acronym = acronyms
            self.Address = address
            self.Founded = founded
            self.Motto = motto
            self.WorldRank = world_rank
            self.CountryRank = country_rank
            self.Phone = telephone_number
            self.Fax = fax

    df = pd.read_csv('University2.csv')
    df
    names_list = df.Name.values
    acronym_list = df.Acronym.values
    address_list = df.Address.values
    founded_list = df.Founded.values
    motto_list = df.Motto.values
    world_rank_list = df.WorldRank.values
    country_rank_list = df.CountryRank.values
    tel_list = df.Phone.values
    fax_list = df.Fax.values

    university_data_list = []

    for i in range(len(names_list)):
        ud = UniversityData(names_list[i] , acronym_list[i] , address_list[i] , founded_list[i] , motto_list[i] , world_rank_list[i] , country_rank_list[i] , tel_list[i] , fax_list[i]    )
        university_data_list.append(ud)
    objects_list=[]
    for object in university_data_list:
        temp = 0
        j=0
        index=0
        
        temp_string = getattr(object , attribute )
        temp_string = (str(temp_string)).lower()
        temp_string=temp_string.replace(",","")
        temp_string=temp_string.replace(" ","")
        key = key.lower()
        for i in range(len(temp_string)):
            if(key[0] == temp_string[i]):
                index = i
                break
        
        while(temp < len(key) and index < len(temp_string)  and key[j] == temp_string[index]):
            index = index+1
            j = j+1
            temp = temp + 1
        if(temp == len(key) ):
            objects_list.append(object)
    name=[]
    acronym=[]
    address=[]
    founded=[]
    motto=[]
    worldRank=[]
    countryRank=[]
    phone=[]
    fax=[]
    for i in objects_list:
        name.append(i.Name)
        acronym.append(i.Acronym)
        address.append(i.Address)
        founded.append(i.Founded)
        motto.append(i.Motto)
        worldRank.append(i.WorldRank)
        countryRank.append(i.CountryRank)
        phone.append(i.Phone)
        fax.append(i.Fax)
    df = pd.DataFrame({'Name':name, 'Acronym':acronym, 'Address':address,'Founded':founded,'Motto':motto,'WorldRank':worldRank,'CountryRank':countryRank,'Phone':phone,'Fax':fax})
    df.to_csv('searchedData.csv', index=False, encoding='utf-8')
                    
def bSearch(startInd,endInd,key,array,attribute):
    if(attribute == "Founded" or attribute == "WorldRank" or attribute == "CountryRank" ):
        m=int((startInd+endInd)/2)
        key=int(key)
        if(endInd-startInd==0):
            return startInd
        if(key>getattr(array[m],attribute)):
            return bSearch(m+1, endInd, key,array,attribute)
        else:
            return bSearch(startInd, m, key,array,attribute)
    else:
        m=startInd+(endInd - startInd)//2
        temp=getattr(array[m],attribute)
        key=key.lower()
        temp=temp.lower()
        name=""
        for i in range(0,len(temp)):
            if(temp[i]!=" "):
                name=name+temp[i]
            else:
                break
        if(key==name):
            return m
        if(endInd-startInd==0):
            return startInd+1
        temp=getattr(array[m],attribute)
        if(key>name):
            return bSearch(m+1, endInd, key,array,attribute)
        else:
            return bSearch(startInd, m, key,array,attribute)
class MergeSort():
    def sortingAlgorithms(self, array,attribute):
        def Merge(start,m,end,array):
            n1=m-start+1
            n2=end-m
            l=[None]*(n1)
            r=[None]*(n2)
            for i in range(0,n1):
                l[i]=array[start+i]
            for i in range(0,n2):
                r[i]=array[m+1+i]
            i=0
            j=0
            k=start
            while i<n1 and j<n2:
                if(getattr(l[i],attribute)>getattr(r[j],attribute)):
                    array[k]=r[j]
                    j+=1
                    k+=1
                else:
                    array[k]=l[i]
                    i+=1
                    k+=1
            while i<n1:
                array[k]=l[i]
                i+=1
                k+=1
            while j<n2:
                array[k]=r[j]
                j+=1
                k+=1
        def MergeSort1(startInd,endInd,array):
            if(startInd<endInd):
                m=((endInd-1)+startInd)//2
                MergeSort1(startInd, m, array)
                MergeSort1(m+1, endInd, array)
                Merge(startInd,m,endInd,array)
            return array
        return MergeSort1(0,len(array)-1,array)

def BinarySearch(attribute,key):
    class UniversityData:
        Name=""
        Acronym=""
        Address=""
        Founded=0
        Motto=""
        WorldRank=0
        CountryRank=0
        Phone=""
        Fax=""

        def __init__(self,name , acronyms , address,founded , motto , world_rank , country_rank,telephone_number , fax):
            self.Name = name
            self.Acronym = acronyms
            self.Address = address
            self.Founded = founded
            self.Motto = motto
            self.WorldRank = world_rank
            self.CountryRank = country_rank
            self.Phone = telephone_number
            self.Fax = fax

    df = pd.read_csv('University2.csv')
    df
    names_list = df.Name.values
    acronym_list = df.Acronym.values
    address_list = df.Address.values
    founded_list = df.Founded.values
    motto_list = df.Motto.values
    world_rank_list = df.WorldRank.values
    country_rank_list = df.CountryRank.values
    tel_list = df.Phone.values
    fax_list = df.Fax.values

    array = []

    for i in range(len(names_list)):
        ud = UniversityData(names_list[i] , acronym_list[i] , address_list[i] , founded_list[i] , motto_list[i] , world_rank_list[i] , country_rank_list[i] , tel_list[i] , fax_list[i]    )
        array.append(ud)
    sort=MergeSort()
    array=sort.sortingAlgorithms(array,attribute)
    objects_list=[]
    startInd=0
    endInd=len(array)
    index=bSearch(startInd,endInd,key,array,attribute)
    objects_list.append(array[index])
    name=[]
    acronym=[]
    address=[]
    founded=[]
    motto=[]
    worldRank=[]
    countryRank=[]
    phone=[]
    fax=[]
    for i in objects_list:
        name.append(i.Name)
        acronym.append(i.Acronym)
        address.append(i.Address)
        founded.append(i.Founded)
        motto.append(i.Motto)
        worldRank.append(i.WorldRank)
        countryRank.append(i.CountryRank)
        phone.append(i.Phone)
        fax.append(i.Fax)
    df = pd.DataFrame({'Name':name, 'Acronym':acronym, 'Address':address,'Founded':founded,'Motto':motto,'WorldRank':worldRank,'CountryRank':countryRank,'Phone':phone,'Fax':fax})
    df.to_csv('searchedData.csv', index=False, encoding='utf-8')

    
#linearSearch("Name","University of engineering and technology lahore")

