import Algorithms
import pandas as pd


class UniversityData:
    name = ""
    acronyms = ""
    address = ""
    founded = 0
    motto = ""
    world_rank = 0
    country_rank = 0
    telephone_number = ""
    fax = ""

    def __init__(self,name , acronyms , address,founded , motto , world_rank , country_rank,telephone_number , fax):
        self.name = name
        self.acronyms = acronyms
        self.address = address
        self.founded = founded
        self.motto = motto
        self.world_rank = world_rank
        self.country_rank = country_rank
        self.telephone_number = telephone_number
        self.fax = fax

df = pd.read_csv('University2.csv')
df
names_list = df.Name.values
acronym_list = df.Acronym.values
address_list = df.Address.values
founded_list = df.Founded.values
motto_list = df.Motto.values
world_rank_list = df.WorldRank.values
country_rank_list = df.CountryRank.values
tel_list = df.Phone.values
fax_list = df.Fax.values

university_data_list = []

for i in range(len(names_list)):
    ud = UniversityData(names_list[i] , acronym_list[i] , address_list[i] , founded_list[i] , motto_list[i] , world_rank_list[i] , country_rank_list[i] , tel_list[i] , fax_list[i]    )
    university_data_list.append(ud)
class CountingSort():
    def sortingAlgorithms(self, array,attribute):
        if(attribute == "founded" or attribute == "world_rank" or attribute == "country_rank" ):
            
            large=array[0]
            b=[0]*len(array)
            for i in range(0,len(array)):
                if(getattr(large,attribute)<getattr(array[i],attribute)):
                    large=array[i]
            c=[0]*(getattr(large,attribute)+1)
            for i in range(0,len(array)):
                rn=getattr(array[i],attribute)
                c[rn]+=1
            for i in range(1,len(c)):
                c[i]+=c[i-1]
            for i in range(len(array)-1,-1,-1):
                b[c[getattr(array[i],attribute)]-1]=array[i]
                c[getattr(array[i],attribute)]=c[getattr(array[i],attribute)]-1
            return(b)
        
        else:
            
            
            b=[0]*len(array)
            c=[0]*27
            for i in range(len(array)):
                tempString = getattr(array[i],attribute)
                tempString = tempString.lower()
                #print(ord(tempString[0]) - 97)
                if(ord(tempString[0]) - 97>25 or ord(tempString[0]) - 97<0):
                    c[26]+=1
                else:
                    c[ord(tempString[0]) - 97]+=1
            
            for i in range(1,len(c)):
                c[i]+=c[i-1]
            
            #print(c)
            dec=len(array)
            for i in range(len(array)-1,-1,-1):
                temp=getattr(array[i],attribute)
                temp=temp.lower()
                count=(ord(temp[0])-97)
                if(count<=25 and count>=0 ):
                    b[c[count]-1]=array[i]
                    c[count]-=1
                else:
                    b[dec-1]=array[i]
                    c[26]-=1
                    dec-=1
                    
            return(b)
def BinarySearch(startInd,endInd,key,array,attribute):
    if(attribute == "founded" or attribute == "world_rank" or attribute == "country_rank" ):
        m=int((startInd+endInd)/2)
        key=int(key)
        if(endInd-startInd==0):
            return startInd
        if(key>getattr(array[m],attribute)):
            return BinarySearch(m+1, endInd, key,array,attribute)
        else:
            return BinarySearch(startInd, m, key,array,attribute)
    else:
        m=startInd+(endInd - startInd)//2
        temp=getattr(array[m],attribute)
        key=key.lower()
        temp=temp.lower()
        name=""
        for i in range(0,len(temp)):
            if(temp[i]!=" "):
                name=name+temp[i]
            else:
                break
        if(key==name):
            return m
        if(endInd-startInd==0):
            return startInd+1
        temp=getattr(array[m],attribute)
        if(key>name):
            return BinarySearch(m+1, endInd, key,array,attribute)
        else:
            return BinarySearch(startInd, m, key,array,attribute)
sort=CountingSort()
university_data_list=sort.sortingAlgorithms(university_data_list,"fax")
out=BinarySearch(0,len(university_data_list)-1,"456",university_data_list,"fax")
print(university_data_list[out].fax)


                    
            
        
    



























